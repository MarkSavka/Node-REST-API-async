const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const User = require('../models/user');
const UserController = require('./../controllers/user');


//! **** Фікс багу з версіями *******
mongoose.set('useCreateIndex', true);
//! *********************************
router.get('/', UserController.get_all);

router.get('/:item', UserController.get_item);

router.post('/login', UserController.post_login);

router.post('/signup', UserController.post_sign_up);

router.delete('/', UserController.delete_all);

router.delete('/:item', UserController.delete_item);

module.exports = router;