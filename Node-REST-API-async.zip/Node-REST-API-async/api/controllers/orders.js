const Order = require('../models/order');
const Product = require('../models/product');

const mongoose = require('mongoose');

exports.orders_get_all = async (req, res, next) => {
    async function findOrder() {
        try{
            var orders = await Order.find();
            return res.status(200).json({count: orders.length, order: orders});
        }catch(e){
            console.log(e)
            res.status(500).json(e)
        }
    }
    (async function() {
        return await findOrder();
    })()
}

exports.orders_get_item = async (req, res, next) => {
    async function findAndPrintOrder() {
        const item = await req.params.item;
        const order = await Order.findOne({_id: item});
        
        console.log(order);
        return res.status(200).json({order: order});
    }
    (async function(){
        try{
            await findAndPrintOrder();
        }
        catch(e){
            console.log(e);
            res.status(200).json(e);
        }
    })()
}

exports.order_post = async (req, res, next) => {
    async function findProduct() {
        try{
            return Product.findById(req.body.product)
        }catch {
            return new Error('Product not found')
        }
    }
    async function createOrder() {
        console.log(req.body);
        const order = await new Order({
            _id: mongoose.Types.ObjectId(),
            product: req.body.product,
            quantity: req.body.quantity
        });
        await order.save();
        return order
    }
    async function main(){
        try{
            let result = await findProduct(); // Is real product ?
            if(result){
                let order = await createOrder(); //Create Order
                res.status(200).json({message:'Order was create', order: order})
            } else res.status(500).json({message:'Product not found'})
        }catch(err) {
            console.log(err);
            res.status(500).json(err);
        } 
    }
    main();
}

exports.order_delete_all = async(req, res, next) => {
    async function deleteOrder() {
        await Order.deleteMany();
        console.log({message: 'All order was delete'});
        res.status(200).json({message: 'All order was delete'});
    }
    (async function() {
        try{
            await deleteOrder();
        }catch(e){
            console.log(e);
            res.status(500).json(e);
        }
    })()
}

exports.order_delete_item = (req, res, next) => {
    const item = req.params.item;
    async function deleteOrder() {
        await Order.deleteOne({_id: item});
        console.log({message: `Order ${item} was delete`});
        return res.status(200).json({message: `Order ${item} was delete`});
    }
    (async function() {
        try{
            await deleteOrder();
        }catch(e){
            console.log(e);
            res.status(500).json(e);
        }
    })()
}