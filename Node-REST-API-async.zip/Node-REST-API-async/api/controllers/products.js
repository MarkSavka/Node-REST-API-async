const Order = require('../models/order');
const Product = require('../models/product');
const mongoose = require('mongoose');

//! ****************************************************

const fs = require('fs');

//! ****************************************************

exports.product_get_all = async (req, res, next) => {
	async function findProduct() {
		var docs = await Product.find();
		return docs;
	}
	async function displayProduct() {
		var docs = await findProduct();
		res.status(200).json({count: docs.length, docs: docs});
    }
    displayProduct();
}

exports.product_get_item = async (req, res, next) => {
	async function getId() {
		var id = await req.params.item;
		return id;
	}
	async function findProduct() {
		var id = await getId();
        var docs = await Product.findOne({_id: id});
        if(docs) return returnProduct(docs);
        else return productNotDefined()
	}
	async function returnProduct(docs) {
		res.status(200).json({
			_id: docs._id,
			name: docs.name,
			price: docs.price,
			productImage: docs.productImage,
			productImageUrl: docs.productImageUrl
        });
    }
    async function productNotDefined(){
        res.status(500).json({message: 'Product not defined'});
    }
	findProduct();
}

exports.product_post = async (req, res, next) => {

    async function create_product() {
        console.log(req.file);
        if(req.body.name || req.body.proce || req.file.productImage)
            return new Product({
                _id: new mongoose.Types.ObjectId(),
                name: req.body.name,
                price: req.body.price,
                productImage: `./` + req.file.path,
                productImageUrl: 'http://localhost:3100/' + (req.file.path || null)
            })
        else
            return res.status(200).json({message:'Чогось не хватає'})
	}

	(async function() {
	
        var product = await create_product();

        try{
            const result = await product.save();
            res.status(200).json({
                name: result.name,
                price: result.price,
                productImage: result.productImage
            })
        }catch(e){
            console.log(e);
            res.status(500).json(e);
        }
    })()
}


exports.product_patch_item = async (req, res, next) => {
	(async function() {
		var id = await req.params.item;
		await Product.update({_id: id}, { $set: {name: req.body.name, price: req.body.price}})
		var docs = await Product.findOne({_id: id});
		res.status(200).json(docs);
	})()
}

exports.product_delete_all = async (req, res, next) => {
    const products = await Product.find(); 
    for (let i = 0; i < products.length; i++) {
        try{
            let tmp = products[i].productImage;
            fs.unlinkSync(tmp, (err) => {
                if(err)
                    console.log(err)
            })
        } catch (e) {console.log(e)} 
        
    }
    await Product.deleteMany();
    res.status(200).json({Message: 'All products was deleted'});
}

exports.product_delete_item = async (req, res, next) => {
    const findId = await req.params.item;

    async function deletePhoto(pathPhoto) {
        if(pathPhoto)
            try{
                fs.unlinkSync(pathPhoto, (err) => {
                    if(err)
                        console.log(err)
                })
            } catch (e) {console.log(e)}         
    }
    async function findPhoto() {
        try{
            var product = await Product.findOne({_id: findId});
            console.log({Message: null, product: product, Path: product.productImage});
            deletePhoto(product.productImage);
        } catch (e) {console.log(e)}
    }
    async function deleteProduct() {
        await Product.remove({_id: findId});
    }
    (async function(){
        await findPhoto();
        await deleteProduct();
        return res.status(200).json({messega: 'Product was delete'});
    })()
}