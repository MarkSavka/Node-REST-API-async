const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const User = require('../models/user');

exports.get_all = async (req, res, next) => {
    async function findUser(){
        const users = await User.find();
        console.log(users);
        return res.status(200).json({count: users.length, user: users});
    }
    (async function(){
        try{
            await findUser();
        }catch(e){
            console.log(e)
            res.status(500).json(e)
        }
    })()
}
exports.get_item = async (req, res, next) => {
    async function findUser(){
        const users = await User.findOne({_id: req.params.item});
        console.log(users);
        return res.status(200).json({user: users});
    }
    (async function(){
        try{
            await findUser();
        }catch(e){
            console.log(e)
            res.status(500).json(e)
        }
    })()
}
exports.post_login = async (req, res, next) => {

    async function checkUser() {
        const user = await User.findOne({email: req.body.email});
        const match = await bcrypt.compare(req.body.password, user.password);
        if(match){
            const token = jwt.sign({
                email: user.email,
                userId: user._id
             }, 'my_private_JWT_KEY', {expiresIn: '2h'}
            )
            res.status(200).json({token: token})
        } else
            res.status(500).json({message: 'Auth error'})
    }
    (async function() {
        try{
            await checkUser();
        }catch(e){
            console.log(e)
            res.status(500).json(e)
        }
    })()
}
exports.post_sign_up = async (req, res, next) => {
    async function testEmail(){
        if(req.body.email){
            if(req.body.password){
                try{
                    const test = await User.findOne({email: req.body.email})
                    if(test){
                        res.status(500).json({message: 'Такий email вже існує'});
                        throw new Error('Такий email вже існує');
                    }
                    else 
                        return true
                        
                }catch(e){
                    console.log(e)
                    res.status(500).json(e)
                }
            } else return res.status(500).json({message: 'Пароль відсутній'})
        } else return res.status(500).json({message: 'Email відсутній'})
    }
    async function createUser() {
        try{
            bcrypt.hash(req.body.password, 10, async (err, hash) => {
                if(err) {
                    return res.status(500).json({
                        message: 'error from hash',
                        error: err
                    });
                } else {
                    const user = new User({
                        _id: mongoose.Types.ObjectId(),
                        email: req.body.email,
                        password: hash
                    });
                    await user.save();
                    console.log(user);
                    return res.status(200).json({message: 'User was created', user: user});
                }  
            });
        } catch{ 
            console.log('Error for create user');
            res.status(500).json({message: 'Error for create user'});
        }
    }
    (async function(){
        try{
            const test = await testEmail();
            if(test){
                await createUser();
            } else {

            }
        }catch{
            res.status(500).json({message: 'Такий email вже існує'});
        }
    })()
}
exports.delete_all = async (req, res, next) => {
    async function deleteUser(){
        try{
            await User.deleteMany()
            console.log('All user deleted')
            return res.status(200).json({message:'All user deleted'})
        }catch(e){
            console.log(e)
            res.status(500).json(e)
        }
    }
    (async function(){
        try{
            await deleteUser();
        } catch(e){
            console.log(e);
            res.status(500).json(e);
        }
    })()
}
exports.delete_item = async (req, res, next) => {
    async function testEmail(){
        try{
            const test = await User.findOne({_id: req.params.item});
            console.log(test);
            return test
        }catch(e){
            console.log(e)
            res.status(500).json(e)
        }
    }
    async function deleteUser(){
        try{
            await User.deleteOne({_id: req.params.item});
            console.log(`User ${req.params.item}`);
            return res.status(200).json({message:'All user deleted'});
        }catch(e){
            console.log(e);
            res.status(500).json(e);
        }
    }
    (async function(){
        try{
            const test = await testEmail();
            if(test){
                await deleteUser()
            }
            else{
                console.log('Email not found');
                return res.status(500).json({message:'Email not found'});
            }
        } catch(e){
            console.log(e);
            res.status(500).json(e);
        }
    })()
}
